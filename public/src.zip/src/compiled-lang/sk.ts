export default {
    "hardware.update": "obnovit"
}