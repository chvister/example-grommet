export default {
    "hardware.update": "Update"
}

