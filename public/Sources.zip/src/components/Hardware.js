import React from "react";
import { Anchor, Box, Text, Heading } from "grommet";
import { Update } from "grommet-icons";
import { useIntl } from 'react-intl';

export const Hardware = ({ data, ...rest }) => {
  const intl = useIntl()
  return (
  <Box direction="column" gap="large">
    <Box round pad="medium" direction="column" background="white" {...rest}>
      <Box gap="small">
        <Heading level="2" margin="none" size="small">
          {data.Hypervisor.name}
        </Heading>
        <Box direction="row" justify="between">
          <Text color="gray" size="small">
            {data.Hypervisor.hardware}
          </Text>
          <Box direction="row" align="center">
            <Box pad={{ horizontal: "small" }}>
              <Anchor href="" label={intl.formatMessage({id: "hardware.update"})} />
            </Box>
            <Update size="small" color="brand" />
          </Box>
        </Box>
        <Text color="gray"> </Text>
      </Box>
    </Box>
    <Box
      round
      pad="medium"
      direction="column"
      background="white"
      justify="between"
      gap="small"
      {...rest}
    >
      <Box>
        <Box gap="small">
          <Heading level="2" margin="none" size="small">
            {data.Hardware.name}
          </Heading>
          <Text color="gray" size="small">
            {" "}
            {data.Hardware.hardware}{" "}
          </Text>
        </Box>
      </Box>
      <Box direction="row" wrap>
        <Box
          flex={false}
          round="small"
          margin="xsmall"
          pad={{ vertical: "small", horizontal: "medium" }}
          border={{ side: "all", color: "accent-4", size: "small" }}
        >
          4 Hosts
        </Box>
        <Box
          flex={false}
          round="small"
          margin="xsmall"
          pad={{ vertical: "small", horizontal: "medium" }}
          border={{ side: "all", color: "accent-2", size: "small" }}
        >
          2 Nodes
        </Box>
      </Box>
    </Box>
  </Box>);
}